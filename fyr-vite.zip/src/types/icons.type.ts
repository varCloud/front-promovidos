import { TDuotoneIcons } from './duotoneIcons.type';
import { THeroIcons } from './heroIcons.type';

export type TIcons = TDuotoneIcons | THeroIcons | string;
