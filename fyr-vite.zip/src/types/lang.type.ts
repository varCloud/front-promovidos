export type TLang = 'en' | 'es' | 'ar';
