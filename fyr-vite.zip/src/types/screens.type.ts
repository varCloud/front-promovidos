export type TScreens = 'sm' | 'md' | 'lg' | 'xl' | '2xl';

export const arrScreens: TScreens[] = ['sm', 'lg', 'xl', '2xl'];
