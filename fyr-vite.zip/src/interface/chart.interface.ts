import { ApexOptions } from 'apexcharts';

export interface IChartOptions {
	series: ApexOptions['series'];
	options: ApexOptions;
}
