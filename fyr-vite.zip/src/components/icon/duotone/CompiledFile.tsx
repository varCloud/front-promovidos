import React, { SVGProps } from 'react';

const SvgCompiledFile = (props: SVGProps<SVGSVGElement>) => {
	return (
		<svg viewBox='0 0 24 24' className='svg-icon' {...props}>
			<g fill='none' fillRule='evenodd'>
				<path d='M0 0h24v24H0z' />
				<path
					d='M5.857 2h7.88a1.5 1.5 0 01.968.355l4.764 4.029A1.5 1.5 0 0120 7.529v12.554c0 1.79-.02 1.917-1.857 1.917H5.857C4.02 22 4 21.874 4 20.083V3.917C4 2.127 4.02 2 5.857 2z'
					fill='currentColor'
					opacity={0.3}
				/>
				<rect
					fill='currentColor'
					opacity={0.3}
					transform='rotate(-45 8.984 12.127)'
					x={7.413}
					y={10.556}
					width={3.143}
					height={3.143}
					rx={0.75}
				/>
				<rect
					fill='currentColor'
					opacity={0.3}
					transform='rotate(-45 15.27 12.127)'
					x={13.699}
					y={10.556}
					width={3.143}
					height={3.143}
					rx={0.75}
				/>
				<rect
					fill='currentColor'
					transform='rotate(-45 12.127 15.27)'
					x={10.556}
					y={13.699}
					width={3.143}
					height={3.143}
					rx={0.75}
				/>
				<rect
					fill='currentColor'
					transform='rotate(-45 12.127 8.984)'
					x={10.556}
					y={7.413}
					width={3.143}
					height={3.143}
					rx={0.75}
				/>
			</g>
		</svg>
	);
};

export default SvgCompiledFile;
